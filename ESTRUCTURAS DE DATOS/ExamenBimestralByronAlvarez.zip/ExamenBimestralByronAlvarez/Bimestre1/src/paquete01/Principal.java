package paquete01;
import paquete02.Medicos;
import paquete02.Enfermeros;
import paquete02.Hospital;

public class Principal {
    public static void main(String[] args) {
        Medicos med1 = new Medicos("Richard Obrien", "Pediatria", 1000f);
        Medicos med2 = new Medicos("Jacob McIntyre", "General", 1100f);
        Medicos med3 = new Medicos("Craig Alexander", "Pedatria", 1200f);
        Medicos med4 = new Medicos("John Hernandez", "Internista", 1000f);
        
        Medicos [] listaMed = {med1, med2, med3, med4};
        
        Enfermeros enf1 = new Enfermeros("William Bradshaw", "Contrato", 800f);
        Enfermeros enf2 = new Enfermeros("Jennifer Muñoz", "Contrato", 700f);
        Enfermeros enf3 = new Enfermeros("Jeffrey Bryant", "Nombramiento", 1000f);
        
        Enfermeros [] listaEnf = {enf1, enf2, enf3};
        
        Hospital hospital1 = new Hospital("Hospital Zaruma", "Zaruma", 10, "Barrio Central");
        hospital1.establecerMedicos(listaMed);
        hospital1.establecerEnfermeros(listaEnf);
        
        hospital1.calcularSueldos();
        
        System.out.println(hospital1);
    }
    
}
