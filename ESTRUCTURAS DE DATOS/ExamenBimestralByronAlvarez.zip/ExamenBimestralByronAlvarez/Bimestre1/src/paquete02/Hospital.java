package paquete02;

public class Hospital {

    private String nombre;
    private String ciudad;
    private int numConsult;
    private Medicos[] medico;
    private Enfermeros[] enfermero;
    private float sueldosTotal;
    private String direccion;

    public Hospital(String n, String c, int numC, String dir) {
        nombre = n;
        ciudad = c;
        numConsult = numC;
        direccion = dir;
    }

    public Hospital(String n, String c, int numC, Medicos[] med, Enfermeros[] enf, String dir) {
        nombre = n;
        ciudad = c;
        numConsult = numC;
        medico = med;
        enfermero = enf;
        direccion = dir;
    }

    public void establecerNombre(String s) {
        nombre = s;
    }

    public void establecerCiudad(String s) {
        ciudad = s;
    }

    public void establecerNumeroConsultorios(int n) {
        numConsult = n;
    }

    public void establecerMedicos(Medicos[] med) {
        medico = med;
    }

    public void establecerEnfermeros(Enfermeros[] enf) {
        enfermero = enf;
    }

    public void establecerDireccion(String s) {
        direccion = s;
    }

    public void calcularSueldos() {
        float suma = 0;
        for (int i = 0; i < medico.length; i++) {
            Medicos medicos = medico[i];
            suma += medico[i].obtenerSueldoMensual();
        }
        for (int i = 0; i < enfermero.length; i++) {
            Enfermeros enfermeros = enfermero[i];
            suma += enfermero[i].obtenerSueldoMensual();
        }
        sueldosTotal = suma;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public String obtenerCiudad() {
        return ciudad;
    }

    public String obtenerDireccion() {
        return direccion;
    }

    public int obtenerNumeroConsultorios() {
        return numConsult;
    }

    public Medicos[] obtenerMedicos() {
        return medico;
    }

    public Enfermeros[] obtenerEnfermeros() {
        return enfermero;
    }
    
    public float obtenerSueldosTotal(){
        return sueldosTotal;
    }
    
    @Override
    public String toString(){
        String cadena = 
                String.format("""
                              %s
                              Direccion: %s
                              Ciudad: %s
                              Numero de Consultorios: %d
                              Listado de medicos:""", 
                        nombre, direccion, ciudad, numConsult);
        for (int i = 0; i < medico.length; i++) {
            Medicos medicos = medico[i];
            cadena = String.format("%s\n- %s - sueldo: %.2f - %s", 
                    cadena, medicos.obtenerNombre(), 
                    medicos.obtenerSueldoMensual(), medicos.obtenerEspecialidad());
        }
        cadena = String.format("%s\n\nLista de Enfermeros(as)", cadena);
        for (int i = 0; i < enfermero.length; i++) {
            Enfermeros enfermeros = enfermero[i];
            cadena = String.format("%s\n- %s - sueldo: %.2f - %s", 
                    cadena, enfermeros.obtenerNombre(), 
                    enfermeros.obtenerSueldoMensual(), 
                    enfermeros.obtenerNombramiento());
        }
        cadena = String.format("%s\n\nTotal de sueldos a pagar: %.2f", 
                cadena, sueldosTotal);
        
        return cadena;
    }
}
