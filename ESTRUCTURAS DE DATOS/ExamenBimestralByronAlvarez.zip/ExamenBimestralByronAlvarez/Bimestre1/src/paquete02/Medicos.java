package paquete02;

public class Medicos {

    private String nombreDoc;
    private String especialidad;
    private float sueldoMensual;

    public Medicos(String nom, String es, float n) {
        nombreDoc = nom;
        especialidad = es;
        sueldoMensual = n;
    }

    public void establecerNombre(String s) {
        nombreDoc = s;
    }

    public void establecerEspecialidad(String s) {
        especialidad = s;
    }

    public void establecerSueldoMensual(float n) {
        sueldoMensual = n;
    }

    public String obtenerNombre() {
        return nombreDoc;
    }

    public String obtenerEspecialidad() {
        return especialidad;
    }

    public float obtenerSueldoMensual() {
        return sueldoMensual;
    }
}
