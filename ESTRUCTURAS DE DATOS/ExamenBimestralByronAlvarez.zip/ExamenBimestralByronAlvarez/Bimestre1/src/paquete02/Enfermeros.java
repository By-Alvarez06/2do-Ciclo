package paquete02;

public class Enfermeros {

    private String nombreEnf;
    private String nombramiento;
    private float sueldoMensual;

    public Enfermeros(String nom, String con, float n) {
        nombreEnf = nom;
        nombramiento = con;
        sueldoMensual = n;
    }

    public void establecerNombre(String s) {
        nombreEnf = s;
    }

    public void establecerNombramiento(String s) {
        nombramiento = s;
    }

    public void establecerSueldoMensual(float n) {
        sueldoMensual = n;
    }

    public String obtenerNombre() {
        return nombreEnf;
    }

    public String obtenerNombramiento() {
        return nombramiento;
    }

    public float obtenerSueldoMensual() {
        return sueldoMensual;
    }
}
